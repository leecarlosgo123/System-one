print("EDDIE LOVESTORY")

name = input("MY NAME IS: ")